package intercambios

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"

	"gorm.io/gorm"
)

// Handler permite trabajar con la base de datos.
type Handler struct {
	DB *gorm.DB
}

// responderJSON devuelve una respuesta JSON.
func responderJSON(w http.ResponseWriter, codigo int, datos interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(codigo)
	_ = json.NewEncoder(w).Encode(datos)
}

// responderError devuelve un mensaje de error.
func responderError(w http.ResponseWriter, codigo int, mensaje string) {
	responderJSON(w, codigo, map[string]string{
		"error": mensaje,
	})
}

// GET /intercambios
func (h *Handler) Listar(w http.ResponseWriter, r *http.Request) {
	var lista []Intercambio

	if err := h.DB.Order("id ASC").Find(&lista).Error; err != nil {
		responderError(w, http.StatusInternalServerError,
			"no se pudieron obtener los intercambios")
		return
	}

	responderJSON(w, http.StatusOK, lista)
}

// GET /intercambios/{id}
func (h *Handler) Obtener(w http.ResponseWriter, r *http.Request, id uint) {
	var intercambio Intercambio

	if err := h.DB.First(&intercambio, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			responderError(w, http.StatusNotFound,
				"intercambio no encontrado")
			return
		}

		responderError(w, http.StatusInternalServerError,
			"error al consultar el intercambio")
		return
	}

	responderJSON(w, http.StatusOK, intercambio)
}

// ValidarUsuarios comprueba el libro, propietario y solicitante.
func (h *Handler) ValidarUsuarios(
	libroID uint,
	solicitanteID uint,
) (uint, int, string) {

	if libroID == 0 {
		return 0, http.StatusBadRequest, "libro_id es obligatorio"
	}

	if solicitanteID == 0 {
		return 0, http.StatusBadRequest, "solicitante_id es obligatorio"
	}

	var libro Libro

	if err := h.DB.First(&libro, libroID).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return 0, http.StatusBadRequest, "el libro no existe"
		}
		return 0, http.StatusInternalServerError, "error al consultar el libro"
	}

	if libro.UsuarioID == 0 {
		return 0, http.StatusBadRequest, "el libro no tiene propietario asignado"
	}

	var propietario Usuario

	if err := h.DB.First(&propietario, libro.UsuarioID).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return 0, http.StatusBadRequest, "el propietario no existe"
		}
		return 0, http.StatusInternalServerError, "error al consultar el propietario"
	}

	var solicitante Usuario

	if err := h.DB.First(&solicitante, solicitanteID).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return 0, http.StatusBadRequest, "el solicitante no existe"
		}
		return 0, http.StatusInternalServerError, "error al consultar el solicitante"
	}

	if libro.UsuarioID == solicitanteID {
		return 0, http.StatusBadRequest, "no puedes solicitar tu propio libro"
	}

	return libro.UsuarioID, 0, ""
}

// TransicionPermitida controla los cambios de estado.
func TransicionPermitida(actual, nuevo string) bool {
	switch actual {
	case EstadoPendiente:
		return nuevo == EstadoAceptado ||
			nuevo == EstadoCancelado

	case EstadoAceptado:
		return nuevo == EstadoEntregado ||
			nuevo == EstadoCancelado

	default:
		return false
	}
}

// POST /intercambios
func (h *Handler) Crear(w http.ResponseWriter, r *http.Request) {
	var entrada struct {
		LibroID       uint   `json:"libro_id"`
		SolicitanteID uint   `json:"solicitante_id"`
		Estado        string `json:"estado"`
	}

	if err := json.NewDecoder(r.Body).Decode(&entrada); err != nil {
		responderError(w, http.StatusBadRequest, "JSON inválido")
		return
	}

	if entrada.Estado == "" {
		entrada.Estado = EstadoPendiente
	}

	// Todo intercambio nuevo debe comenzar pendiente.
	if entrada.Estado != EstadoPendiente {
		responderError(w, http.StatusUnprocessableEntity,
			"un intercambio nuevo debe comenzar pendiente")
		return
	}

	propietarioID, codigo, mensaje := h.ValidarUsuarios(
		entrada.LibroID,
		entrada.SolicitanteID,
	)

	if codigo != 0 {
		responderError(w, codigo, mensaje)
		return
	}

	var libro Libro

	if err := h.DB.First(&libro, entrada.LibroID).Error; err != nil {
		responderError(w, http.StatusInternalServerError,
			"error al consultar el libro")
		return
	}

	if !libro.Disponible {
		responderError(w, http.StatusBadRequest,
			"el libro no está disponible")
		return
	}

	nuevo := Intercambio{
		LibroID:         entrada.LibroID,
		SolicitanteID:   entrada.SolicitanteID,
		UsuarioOfreceID: propietarioID,
		UsuarioRecibeID: entrada.SolicitanteID,
		Estado:          EstadoPendiente,
	}

	if err := h.DB.Create(&nuevo).Error; err != nil {
		responderError(w, http.StatusInternalServerError,
			"no se pudo crear el intercambio")
		return
	}

	responderJSON(w, http.StatusCreated, nuevo)
}

// PUT /intercambios/{id}
func (h *Handler) Actualizar(
	w http.ResponseWriter,
	r *http.Request,
	id uint,
) {
	var intercambio Intercambio

	if err := h.DB.First(&intercambio, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			responderError(w, http.StatusNotFound,
				"intercambio no encontrado")
			return
		}

		responderError(w, http.StatusInternalServerError,
			"error al consultar el intercambio")
		return
	}

	var entrada struct {
		LibroID       uint   `json:"libro_id"`
		SolicitanteID uint   `json:"solicitante_id"`
		Estado        string `json:"estado"`
	}

	if err := json.NewDecoder(r.Body).Decode(&entrada); err != nil {
		responderError(w, http.StatusBadRequest, "JSON inválido")
		return
	}

	if !EstadoValido(entrada.Estado) {
		responderError(w, http.StatusUnprocessableEntity,
			"estado no válido")
		return
	}

	if entrada.Estado != intercambio.Estado &&
		!TransicionPermitida(intercambio.Estado, entrada.Estado) {
		responderError(w, http.StatusUnprocessableEntity,
			"transición de estado no permitida")
		return
	}

	propietarioID, codigo, mensaje := h.ValidarUsuarios(
		entrada.LibroID,
		entrada.SolicitanteID,
	)

	if codigo != 0 {
		responderError(w, codigo, mensaje)
		return
	}

	intercambio.LibroID = entrada.LibroID
	intercambio.SolicitanteID = entrada.SolicitanteID
	intercambio.UsuarioOfreceID = propietarioID
	intercambio.UsuarioRecibeID = entrada.SolicitanteID
	intercambio.Estado = entrada.Estado

	if err := h.DB.Save(&intercambio).Error; err != nil {
		responderError(w, http.StatusInternalServerError,
			"no se pudo actualizar el intercambio")
		return
	}

	responderJSON(w, http.StatusOK, intercambio)
}

// PATCH /intercambios/{id}
// Modifica únicamente el estado del intercambio.
func (h *Handler) CambiarEstado(
	w http.ResponseWriter,
	r *http.Request,
	id uint,
) {
	var intercambio Intercambio

	if err := h.DB.First(&intercambio, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			responderError(w, http.StatusNotFound,
				"intercambio no encontrado")
			return
		}

		responderError(w, http.StatusInternalServerError,
			"error al consultar el intercambio")
		return
	}

	var entrada struct {
		Estado string `json:"estado"`
	}

	if err := json.NewDecoder(r.Body).Decode(&entrada); err != nil {
		responderError(w, http.StatusBadRequest, "JSON inválido")
		return
	}

	if !EstadoValido(entrada.Estado) {
		responderError(w, http.StatusUnprocessableEntity,
			"estado no válido")
		return
	}

	if !TransicionPermitida(intercambio.Estado, entrada.Estado) {
		responderError(w, http.StatusUnprocessableEntity,
			"transición de estado no permitida")
		return
	}

	// Solo actualiza la columna estado.
	if err := h.DB.Model(&intercambio).
		Update("estado", entrada.Estado).Error; err != nil {
		responderError(w, http.StatusInternalServerError,
			"no se pudo actualizar el estado")
		return
	}

	intercambio.Estado = entrada.Estado
	responderJSON(w, http.StatusOK, intercambio)
}

// DELETE /intercambios/{id}
func (h *Handler) Eliminar(
	w http.ResponseWriter,
	r *http.Request,
	id uint,
) {
	var intercambio Intercambio

	if err := h.DB.First(&intercambio, id).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			responderError(w, http.StatusNotFound,
				"intercambio no encontrado")
			return
		}

		responderError(w, http.StatusInternalServerError,
			"error al consultar el intercambio")
		return
	}

	if err := h.DB.Delete(&intercambio).Error; err != nil {
		responderError(w, http.StatusInternalServerError,
			"no se pudo eliminar el intercambio")
		return
	}

	responderJSON(w, http.StatusOK, map[string]string{
		"mensaje": "intercambio eliminado correctamente",
	})
}

// RUTAS
func (h *Handler) Rutas(w http.ResponseWriter, r *http.Request) {
	ruta := strings.Trim(r.URL.Path, "/")
	partes := strings.Split(ruta, "/")

	// /intercambios
	if len(partes) == 1 && partes[0] == "intercambios" {
		switch r.Method {
		case http.MethodGet:
			h.Listar(w, r)
		case http.MethodPost:
			h.Crear(w, r)
		default:
			responderError(w, http.StatusMethodNotAllowed,
				"método no permitido")
		}
		return
	}

	// /intercambios/{id}
	if len(partes) == 2 && partes[0] == "intercambios" {
		numero, err := strconv.ParseUint(partes[1], 10, 64)

		if err != nil || numero == 0 {
			responderError(w, http.StatusBadRequest, "ID inválido")
			return
		}

		id := uint(numero)

		switch r.Method {
		case http.MethodGet:
			h.Obtener(w, r, id)
		case http.MethodPut:
			h.Actualizar(w, r, id)
		case http.MethodPatch:
			h.CambiarEstado(w, r, id)
		case http.MethodDelete:
			h.Eliminar(w, r, id)
		default:
			responderError(w, http.StatusMethodNotAllowed,
				"método no permitido")
		}
		return
	}

	responderError(w, http.StatusNotFound, "ruta no encontrada")
}
